/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, PHP, Ruby, 
C#, VB, Perl, Swift, Prolog, Javascript, Pascal, HTML, CSS, JS
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <iostream>
#include "Video.h"
#include "Peli.h"
#include "Serie.h"
#include "Episodio.h"
#include "Peliculas.h"
int main(){
    
    string genero;
    Peliculas directorioPeliculas{};
    
    directorioPeliculas.leerArchivo();
    
    cout << "Teclea el genero que quieres:";
    cin >> genero;
    directorioPeliculas.reporteGenero(genero);
    
    
    //Declaracion de video 
    Video video1;
    //Declaracion de un video con parametros
    Video video2{"001","Drama de los rayados",120,"Drama, Tragedia, Eliminacion",-100};
    
    //Desplegar el video1
    cout << video1.str() << endl;
    cout << video2.str() << endl;

    //Declaracion de peli 
    Peli peli1;
    //Declaracion de una peli con parametros
    Peli peli2{"002","Forrest Gump",142,"Drama/Romance",100,12};
    
    //Desplegar la peli
    cout << peli1.str() << endl;
    cout << peli2.str() << endl;


    //Declaracion de serie
    Serie reina{"003","The Crown",300,"Drama",0};
    Episodio epi1{"La coronacion",1,100};
    
    reina.setEpisodio(0,epi1);
    reina.setCantidad(reina.getCantidad()+1);
    reina.setEpisodio(1,epi1);
    reina.setCantidad(reina.getCantidad()+1);

    Peli pelic {"004","Los 3 chiflados",120,"Drama/Romance",100,3};
    //Declaracion de un arreglo de apuntadores 
    Video *arrPtrVideos[]= {&video1, &video2, &reina,&pelic};
    
    //Desplegar los prt- apuntadores- direccion de memoria
    cout <<"Ptrs del arreglo Video\n";
    for(int index=0; index < 4; index++){
        cout << arrPtrVideos[index]<<endl;
        cout << arrPtrVideos[index]->str()<< endl;
    }
    
    
    // Desplegar la Serie
    cout << reina.str() << endl;
    
    //Declaracion de Episodio 
    Episodio Episodio1;
    //Declaracion de un video con parametros
    Episodio Episodio2{"Antártida",1,100};
    
    //Desplegar el Episodio
    cout << Episodio1.str() << endl;
    cout << Episodio2.str() << endl;
    return 0;
}
