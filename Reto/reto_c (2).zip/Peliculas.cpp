#include "Peli.h"
#include "Peliculas.h"
#include <sstream>
#include <fstream>

Peliculas::Peliculas(){}
Peliculas::Peliculas(string _id, string _titulo, int _duracion, string _genero, double _calificacionPromedio, int oscares){
}
   
//otros Metodos

void Peliculas::leerArchivo()
{   
    fstream fin;
    //
    string row[6]
    //
    string line, word;
    
    //Abrir archivo de entrada
    fin.open("Pelicula.csv");
    
    //Inicializar el atributo cantidad con 0
    cantidad=0;
    
    //lee una linea del archivo y la almacena en line
    while (getline(fin,line)){
        //Despliega en consola la linea 
        cout<< cantidad<< line<< endl;
        
        //usado para separar las palabras split
        stringstream s(line)
        
        //read every colum data of a row and
        //store it in a string variable, 'word'
        int iR=0;
        
        //Extrae caracteres de s y los almacena en word hasta que encuentra el delimitador
        while (getline(s,word,',')){
            //añade la word al arreglo row e incrementa iR p/la proxima palabras
            row[iR++]=word;
        }    
            setPtrPelicula(new Peli(row[0], row[1], stoi(row[2]), row[3], stod(row[4]), stoi(row[5]));
            
           
    }
    fin.close();
        
        //Sale de ciclo cuando ya no existen mas lineas en el archivo
        
        //Desplegar todas las Peliculas leidas
        for(int iR=0; iR<cantidad;iR++){
            cout<< iR <<"-"<<arrPtrPeliculas[iR]->str()<<endl;
        }
}
    //Metodos modificadores(SETS)
    void Peliculas::setPtrPelicula(Peli *_ptrPelicula){
        if (cantidad<50){
            arrPtrPeliculas[cantidad++]= _ptrPelicula; 
        }
    }
    void Peliculas::setCantidadPeliculas(int _cantidad){
        
    }

    //Metodos de acceso(GETS)
    Peli * Peliculas::getPtrPelicula(string _id){
       return new Peli;
    }
    int Peliculas::getCantidadPeliculas(){
        return cantidad;
    }
  
    //otros Metodos
    void leerArchivo()
    {}
    
    void reporteTodasLasPeliculas(){}
    void reporteConCalificacion(double _calificacionPromedio){
        
    }
    void reporteGenero(string _genero){
        int count=0;
        for (int iR=0; iR < cantidad; iR++){
            if (arrPtrPeliculas[iR]-> getGenero()== _genero)
            {
                cout<< iR<< ' ' << arrPtrPeliculas[iR]->str()<<endl;
                count++;
            }
            
            
        }
        if (count==0)
        cout<<"No hay peliculas del genero" << _genero <<endl;
    }
