
void Peliculas::leerArchivo()
{   //fin- file input
    fstream fin;
    //
    string row[6]
    //
    string line, word;
    
    //Abrir archivo de entrada
    fin.open("Path en tu laptop/Pelicula.csv");
    
    //Inicializar el atributo cantidad con 0
    cantidad=0;
    //lee una linea del archivo y la almacena en line
    while (getline(fin,line)){
        //Despliega en consola la linea 
        cout<< cantidad<< line<< endl;
        
        //usado para separar las palabras split
        stringstream s(line)
        
        //read every colum data of a row and
        //store it in a string variable, 'word'
        int iR=0;
        
        //Extrae caracteres de s y los almacena en word hasta que encuentra el delimitador
        while (getline(s,word,',')){
            //añade la word al arreglo row e incrementa iR p/la proxima palabras
            row[iR++]=word;
        }    
            arrPtrPeliculas[cantidad]=new Peli(row[0], row[1], stoi(row[2]), row[3], stod(row[4]), stoi(row[5]));
            
            //Se muestra en consola la separacion 
            cout << "iD" << row[0] << "\n";
            cout << "Titulo" << row[1] << "\n";
            cout << "Duracion" << row[2] << "\n";
            cout << "Genero" << row[3] << "\n";
            cout << "Calificacion" << row[4] << "\n";
            cout << "Oscares" << row[5] << "\n";
             
            //Desplegamos en consola la pelicula con el metodo str() de Peli
            cout << "Dentro del objeto:" << arrPtrPeliculas[cantidad]->str()<<endl;
            
            //incrementar el atributo cantidad para la siguiente pelicula
            cantidad=cantidad+1;
        }
        fin.close();
        
        //Sale de ciclo cuando ya no existen mas lineas en el archivo
        
        //Desplegar todas las Peliculas leidas
        for(int iR=0; iR<cantidad;iR++){
            cout<< iR <<"-"<<arrPtrPeliculas[iR]->str()<<endl;
        }
}